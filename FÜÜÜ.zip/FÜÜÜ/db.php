<?php
	$db_server = 'linuxserver';
	$db_username = 'ststeraf';
	$db_password = 'mypass';
	$db_database = 'projekt_fu';
	$db = mysqli_connect($db_server,$db_username,$db_password,$db_database);
?>