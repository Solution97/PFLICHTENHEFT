$(document).ready(function(){
	$('.modal').modal();
});
  
$(document).ready(function(){
	$('.modal').modal();
});
	
$(document).ready(function() {
	$('select').material_select();
});
	  
$(document).ready(function(){
	$('.tooltipped').tooltip({delay: 50});
});